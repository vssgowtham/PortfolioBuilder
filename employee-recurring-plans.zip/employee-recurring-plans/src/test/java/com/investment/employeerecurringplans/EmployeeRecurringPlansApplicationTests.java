package com.investment.employeerecurringplans;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeRecurringPlansApplicationTests {

    @Test
    void contextLoads() {
    }

}
