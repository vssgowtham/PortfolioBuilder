package com.investment.employeerecurringplans;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeRecurringPlansApplication {

    public static void main(String[] args) {
        SpringApplication.run(EmployeeRecurringPlansApplication.class, args);
    }

}
