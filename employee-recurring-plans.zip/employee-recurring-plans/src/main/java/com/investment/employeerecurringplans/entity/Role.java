package com.investment.employeerecurringplans.entity;

public enum Role {
    USER, ADMIN
}
